/* Read-only expression for the already-rendered Dashi HTML in an authorized cloud browser.
   It executes no library code, fetches nothing, and does not mutate page or remote state. */
(() => {
  const round = n => Math.round(n * 1000000) / 1000000;
  return [...document.querySelectorAll('.bespoke-slide')].map(slide => {
    const root = slide.querySelector('.bespoke-root'), box = root.getBoundingClientRect();
    const scale = box.width / 1920;
    const rect = el => { const r = el.getBoundingClientRect(); return {x:round((r.x-box.x)/scale), y:round((r.y-box.y)/scale), w:round(r.width/scale), h:round(r.height/scale)}; };
    const components = [...slide.querySelectorAll('.bespoke-grid > [data-bespoke-element]')];
    const values = components.map((component,index) => {
      const style=getComputedStyle(component);
      const texts=[...component.querySelectorAll('*')].filter(el => !el.children.length && el.textContent.trim()).map(el => {
        const s=getComputedStyle(el), lines=[];
        for(const child of el.childNodes){if(child.nodeType!==Node.TEXT_NODE)continue;
          for(let offset=0;offset<child.textContent.length;){const code=child.textContent.codePointAt(offset),size=code>0xFFFF?2:1,range=document.createRange();range.setStart(child,offset);range.setEnd(child,offset+size);const r=range.getBoundingClientRect(),char=child.textContent.slice(offset,offset+size);let line=lines.find(l=>Math.abs(l.top-r.top)<1);if(!line){line={top:r.top,text:''};lines.push(line);}line.text+=char;offset+=size;}
        }
        const rawBounds=rect(el);let clipped={...rawBounds},clippedBy=[];
        for(let ancestor=el.parentElement;ancestor&&root.contains(ancestor);ancestor=ancestor.parentElement){const as=getComputedStyle(ancestor),ar=rect(ancestor);let changed=false;
          if(['hidden','clip','auto','scroll'].includes(as.overflowX)){const x=Math.max(clipped.x,ar.x),end=Math.min(clipped.x+clipped.w,ar.x+ar.w);if(x>clipped.x+.05||end<clipped.x+clipped.w-.05)changed=true;clipped.x=x;clipped.w=Math.max(0,end-x);}
          if(['hidden','clip','auto','scroll'].includes(as.overflowY)){const y=Math.max(clipped.y,ar.y),end=Math.min(clipped.y+clipped.h,ar.y+ar.h);if(y>clipped.y+.05||end<clipped.y+clipped.h-.05)changed=true;clipped.y=y;clipped.h=Math.max(0,end-y);}
          if(changed)clippedBy.push({tag:ancestor.tagName,kind:ancestor.dataset.bespokeElement||null,bounds:ar,overflowX:as.overflowX,overflowY:as.overflowY});if(ancestor===root)break;
        }
        return {text:el.textContent,renderedText:s.textTransform==='uppercase'?el.textContent.toUpperCase():el.textContent,editablePath:el.getAttribute('data-editable-path'),bounds:rawBounds,visibleBounds:clipped,clippedBy,fontFamily:s.fontFamily,fontSize:Number.parseFloat(s.fontSize),fontWeight:s.fontWeight,lineHeight:s.lineHeight,letterSpacing:s.letterSpacing,color:s.color,textAlign:s.textAlign,textTransform:s.textTransform,lines:lines.sort((a,b)=>a.top-b.top).map(l=>l.text)};
      });
      const listRows=component.dataset.bespokeElement==='list'?[...component.firstElementChild.children].map(el=>({bounds:rect(el),borderTopWidth:Number.parseFloat(getComputedStyle(el).borderTopWidth),borderTopColor:getComputedStyle(el).borderTopColor})):[];
      return {index,type:component.dataset.bespokeElement,bounds:rect(component),gridColumn:style.gridColumn,gridRow:style.gridRow,texts,listRows};
    });
    return {logicalId:slide.dataset.vmSourceSlideId,variantId:slide.dataset.vmVariantId,theme:slide.dataset.themePack,sourceCanvas:{width:1920,height:1080},viewport:{width:innerWidth,height:innerHeight},rootTransformScale:scale,components:values};
  });
})()
