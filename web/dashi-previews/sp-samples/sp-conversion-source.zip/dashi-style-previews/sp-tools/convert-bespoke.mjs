/** Dashi v4 → editable SP canonical. Offline local artifact converter, no network/product writes.
 * Geometry translates BespokeSlide.jsx at Dashi commit 21dc7e5. Typography uses source rules,
 * with explicitly marked initial estimates; verified browser DOM replaces them when available.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {materializeBespokeComposition} from '../vendor-work/src/variant-materializer.mjs';
import {resolveContentMap,validateBespokeComposition,requiredPageContentFacts,requiredPageChartFacts} from '../vendor-work/src/variant-contract.mjs';
import {getBespokeThemeProfile} from '../vendor-work/src/components/bespoke/theme-profiles.mjs';
const mainCore=fs.existsSync(new URL('../sp-validation/main/core/document-core.js',import.meta.url))?await import('../sp-validation/main/core/document-core.js'):null;
const mainAdapter=fs.existsSync(new URL('../sp-validation/main/adapters/editor-v038-model.js',import.meta.url))?await import('../sp-validation/main/adapters/editor-v038-model.js'):null;
const pr3Core=fs.existsSync(new URL('../sp-validation/pr3/core/document-core.js',import.meta.url))?await import('../sp-validation/pr3/core/document-core.js'):null;
const pr3Adapter=fs.existsSync(new URL('../sp-validation/pr3/adapters/editor-v038-model.js',import.meta.url))?await import('../sp-validation/pr3/adapters/editor-v038-model.js'):null;
const genericRenderer = fs.existsSync(new URL('../sp-validation/main/vendor/reveal-bundle.js', import.meta.url)) ? await import('../sp-validation/main/io/html.js') : null;

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const MAP=JSON.parse(fs.readFileSync(path.join(ROOT,'SP-ADAPTATION-MAPPING.json'),'utf8'));
const SCALE=2/3,DATE='2026-10-11T00:00:00.000Z';
const SOURCES={dashi:'21dc7e5fc8c3a0d7f6a94948153dd1ee954f4e64',main:'5314ac9bd71b98e93852ec990146d77c98b7f361',pr3:'24ea406fa52df32e3a618ee804af0c0cf1fa7abf'};
const rnd=v=>Math.round(v*1e6)/1e6;
const sz=b=>Object.fromEntries(['x','y','w','h'].map(k=>[k,rnd(b[k]*SCALE)]));
const clone=v=>JSON.parse(JSON.stringify(v));
const sha=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const hex=(v,bg='#ffffff')=>{
 if(!v||v==='transparent')return 'transparent';
 if(v.startsWith('#'))return v.toUpperCase();
 const m=v.match(/^rgba?\(([^)]+)\)$/);if(!m)throw Error(`Unsupported color ${v}`);
 const ns=m[1].split(',').map(Number),alpha=ns[3]??1;
 const base=[1,3,5].map(i=>parseInt(bg.slice(i,i+2),16));
 return '#'+ns.slice(0,3).map((x,i)=>Math.round(x*alpha+base[i]*(1-alpha)).toString(16).padStart(2,'0')).join('').toUpperCase();
};
const roles={kicker:{size:21,lh:1.2,weight:780,letter:.15,upper:true},title:{size:76,lh:1.02,weight:900,letter:-.035},subtitle:{size:38,lh:1.24,weight:650,letter:-.012},body:{size:28,lh:1.5,weight:450,letter:0},label:{size:19,lh:1.2,weight:750,letter:.14,upper:true},caption:{size:21,lh:1.4,weight:500,letter:.02}};
function textRole(e,family,text,editorial){
 if(!editorial)return roles[e.role]||roles.body;
 const n=[...text].length;
 if(['kicker','label'].includes(e.role))return {size:18,lh:1.2,weight:800,letter:.14,upper:true};
 if(e.role==='title'){const base=family==='ledger'?78:family==='media-split'?68:family==='chart-led'?58:46;return {size:n<=14?base:n<=24?base-10:Math.max(38,base-20),lh:1.02,weight:800,letter:-.035};}
 if(e.role==='subtitle')return {size:n>70?24:30,lh:1.22,weight:650,letter:-.012};
 if(e.role==='body')return {size:n>90?21:25,lh:1.45,weight:500,letter:0};
 return {size:n>70?17:20,lh:1.4,weight:520,letter:.01};
}
function profileFor(p,b){
 if(p.editorial)return p;
 if(b==='accent')return {...p,bg:p.accent,surface:'rgba(0,0,0,.14)',ink:'#ffffff',muted:'rgba(255,255,255,.74)',line:'rgba(255,255,255,.24)',accent:p.accent2};
 if(b==='dark')return {...p,bg:'#0b0b0d',surface:'rgba(255,255,255,.08)',ink:'#f7f7f4',muted:'rgba(247,247,244,.68)',line:'rgba(247,247,244,.18)'};
 if(b==='light')return {...p,bg:'#f4f3ef',surface:'rgba(255,255,255,.78)',ink:'#171714',muted:'#6f706b',line:'rgba(23,23,20,.16)'};
 if(b==='surface')return {...p,bg:p.surface};
 return p;
}
function tone(p,t){return t==='accent'?p.accent:t==='positive'?p.accent2:t==='warning'?(p.chartTreatment.series[2]||p.accent2):t==='critical'?(p.chartTreatment.series[3]||'#ef4444'):t==='muted'?p.muted:t==='inverse'?'#ffffff':p.ink;}
function gridBox(g,p){
 const px=p.padX??p.pad,py=p.padY??p.pad,cw=(1920-2*px-11*p.gap)/12,rh=(1080-2*py-7*p.gap)/8;
 return {x:px+(g.column-1)*(cw+p.gap),y:py+(g.row-1)*(rh+p.gap),w:g.width*cw+(g.width-1)*p.gap,h:g.height*rh+(g.height-1)*p.gap};
}
// Explicit deterministic CJK/Latin advance estimate. Not a browser/font measurement.
function wrapText(text,width,size,letter=0){
 let result=[],line='',used=0;for(const c of String(text)){if(c==='\n'){result.push(line);line='';used=0;continue;}const advance=size*((c.codePointAt(0)>255)?1:(/[MW@#]/.test(c)?.86:/[il.,:;'!| ]/.test(c)?.32:.6))+size*letter;if(used+advance>width&&line){result.push(line);line='';used=0;}line+=c;used+=advance;}result.push(line);return result;
}
function formatDatum(d){const text=d.displayValue||String(d.value);return !d.unit||text.includes(d.unit)?text:text+(/^[%‰°℃℉]/.test(d.unit)?'':' ')+d.unit;}
async function build(theme){
 const sourcePath=path.join(ROOT,theme,'goal.json'),sourceText=fs.readFileSync(sourcePath,'utf8'),goal=JSON.parse(sourceText);
 const measureFile=path.join(ROOT,theme,'bespoke-dom-measurements.json');
 const measures=!process.argv.includes('--unmeasured')&&fs.existsSync(measureFile)?JSON.parse(fs.readFileSync(measureFile,'utf8')):null;
 const mapping=MAP.styles.find(v=>v.theme_key===theme),base=getBespokeThemeProfile(theme);
 const report={format:'dashi-to-sp-bespoke-mapping-report',schemaVersion:1,theme,createdAt:new Date().toISOString(),sourceCommits:SOURCES,sourceGoalSha256:sha(sourceText),scope:'Three actual canonical v4 compositions only; v1–v3 upstream templates are NOT converted',canvas:{source:{width:1920,height:1080,evidence:'BespokeSlide.jsx rootStyle fixed width/height'},target:{width:1280,height:720},scale:SCALE,columns:12,rows:8},sourceLicense:'Dashi source AGPL-3.0; source and modification notices remain required',spDeployment:'No SP product change, API write, theme install or production deployment',geometryStatus:'Grid and card/line geometry calculated from fixed source; text wrapping and font metrics not browser-verified',slides:[],lossManifest:[],validation:{},nativeEditorVisualQA:'not_run',pptxQA:'not_run',fontsDownloadedOrEmbedded:false};
 const doc={format:'superior-point',schemaVersion:1,id:`dashi-${theme}-bespoke-v4-${sha(sourceText).slice(0,12)}`,title:`${goal.title} · Dashi ${theme} SP 可编辑样例`,revision:0,canvas:{width:1280,height:720},slides:[],assets:[],metadata:{createdAt:DATE,updatedAt:DATE},extensions:{dashiConversion:{theme,variant:'v4',commit:SOURCES.dashi,sourceGoalSha256:sha(sourceText),scope:'bespoke-only',fidelity:'editable_structure_with_documented_visual_losses',sourceCanvas:{width:1920,height:1080},scale:SCALE}}};
 report.deliveryClass=measures?'source-dom-calibrated':'experimental-unmeasured';
 if(!measures)doc.extensions.dashiConversion.geometryVerification='source_rules_only_unmeasured';
 if(process.argv.includes('--unmeasured')&&fs.existsSync(measureFile))report.excludedDomMeasurement={sha256:sha(fs.readFileSync(measureFile,'utf8')),status:'Explicitly excluded stale/unverified snapshot; no browser geometry conclusion'};
 const loss=(scope,property,handling,detail)=>report.lossManifest.push({scope,property,handling,detail});
 loss('all-slides','typography.fontWeight','quantized','SP native text uses bold 750 or normal 400 and generic SVG uses 700/400; source weights remain in source mapping.');
 loss('all-slides','fontFamily','primary-family-only','SP native renderer quotes the whole fontFamily string, so source CSS fallback stack cannot safely be passed as a single family. Primary family retained; no fonts embedded or installed; device fallback unverified.');
 loss('all-slides','textWrap / text metrics','source-rule estimate','CJK/Latin deterministic advance estimates place internal text and explicit line breaks. Grid bounds are exact but font metrics, baseline, balanced wrapping and clipping need actual native-editor QA.');
 loss('all-slides','transparent surfaces','composited flat color','RGBA surfaces/lines are composited on disclosed flat slide background; gradient and optical blending are not preserved.');
 loss('all-slides','generic renderer','known renderer gaps','Generic SVG uses Arial, ignores text alignment, custom line height, some stroke widths and native roundRect. Adapter validation is not visual validation.');
 for(const logical of goal.slides){
  const v=logical.variants.find(x=>x.id==='v4'&&x.kind==='bespoke');if(!v)throw Error(`${theme}/${logical.id}: missing actual v4`);
  const material=resolveContentMap(logical.content,v.contentMap,materializeBespokeComposition(v.composition,logical.content.presentation,v.projection));
  const errs=validateBespokeComposition(material);if(errs.length)throw Error(JSON.stringify(errs));
  const p=profileFor(base,material.background),fallback=mapping.proposed_bespoke_token_mapping.flattened_solid_colors.background;
  const bg=p.bg.startsWith('#')?p.bg.toUpperCase():p.bg.startsWith('rgb')?hex(p.bg,fallback):fallback;
  const sid=`${theme}-${logical.id}-v4`;
  const slide={id:sid,title:logical.content.presentation.title.short,background:bg,elements:[],animations:[],notes:logical.content.presentation.summary.full};
  const sr={sourceLogicalId:logical.id,sourceVariantId:'v4',sourceLayoutRationale:material.designIntent?.rationale,sourceComposition:material,sourceCanvas:{width:1920,height:1080},profile:{padX:p.padX??p.pad,padY:p.padY??p.pad,gap:p.gap,radius:p.radius},flatBackground:bg,objects:[],sourceFacts:requiredPageContentFacts(logical.content.presentation),sourceChartFacts:requiredPageChartFacts(logical.content.presentation)};
  const family=material.elements.some(e=>e.type==='chart')?'chart-led':material.elements.some(e=>e.type==='media')?'media-split':material.elements.some(e=>e.type==='metric')?'metric-hero':material.elements.some(e=>e.type==='quote')?'statement':'ledger';
  let serial=0,current=null;
  function add(type,name,b,props={},note={}){const id=`${sid}-${++serial}-${name}`;const item={id,name,type,...sz(b),...props};slide.elements.push(item);sr.objects.push({targetId:id,sourceElementId:current?.id??null,sourceElementType:current?.type??'decoration',sourceBounds:clone(b),targetBounds:sz(b),...note});return item;}
  function rect(name,b,fill,radius=0,stroke='transparent',width=0){return add('shape',name,b,{shape:radius>0?'roundRect':'rect',fill:hex(fill,bg),stroke:hex(stroke,bg),strokeWidth:rnd(width*SCALE),radius:rnd(radius*SCALE),cornerRadius:rnd(radius*SCALE),rotation:0,opacity:1,locked:false});}
  function line(name,x1,y1,x2,y2,color,width){const dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy);const obj=rect(name,{x:(x1+x2)/2-len/2,y:(y1+y2)/2-width/2,w:len,h:width},color,0);obj.rotation=rnd(Math.atan2(dy,dx)*180/Math.PI);return obj;}
  function txt(name,text,b,size,lh=1.4,weight=400,color=p.ink,font=p.fontBody,align='left',letter=0,upper=false){
   text=String(text??'');if(!text)return null;
   const primary=font.split(',')[0].replace(/["']/g,'').trim();
   const lines=wrapText(upper?text.toUpperCase():text,b.w,size,letter);const originalText=text;
   return add('text',name,b,{text:lines.join('\n'),fontFamily:primary,fontSize:rnd(size*SCALE),fontWeight:weight>=600?700:400,bold:weight>=600,lineHeight:lh,letterSpacing:rnd(size*letter*SCALE),color:hex(color,bg),align,valign:'top',padding:0,rotation:0,opacity:1,locked:false},{sourceText:originalText,sourceFontStack:font,sourceFontWeight:weight,sourceFontSize:size,sourceLineHeight:lh,sourceLetterSpacingEm:letter,wrapMethod:'estimated CJK/Latin advance; not DOM-measured',estimatedLines:lines.length});
  }
  function panel(e,b){
   if(p.editorial)return;
   if(theme==='theme03')rect('source-hard-shadow',{...b,x:b.x+8,y:b.y+8},hex('rgba(39,66,236,.72)',bg));
   else if(p.shadow!=='none')loss(`${sid}/${e.id}`,'boxShadow','omitted',p.shadow);
   rect('panel',b,p.surface,p.radius,p.line,1);
  }
  if(!p.bg.startsWith('#')&&!p.bg.startsWith('rgb'))loss(sid,'background gradient','flat background',`Source ${p.bg}; flattened to ${bg}.`);
  if(!p.editorial)loss(sid,'ambient blur','omitted','Two source 620×620 ambient circles with blur(130px) and opacity .1 omitted.');
  if(p.editorial)p.spectrum.forEach((c,i)=>rect(`spectrum-${i+1}`,{x:p.padX+i*(1920-2*p.padX)/p.spectrum.length,y:0,w:(1920-2*p.padX)/p.spectrum.length,h:p.strongRule},c));
  // Source CSS puts shape z-index 0 beneath other elements z-index 2.
  const ordered=material.elements.map((e,i)=>({e,i})).sort((a,b)=>(a.e.type==='shape'?0:2)-(b.e.type==='shape'?0:2)||a.i-b.i);
  for(const {e,index} of ordered){
   current=e;const b=gridBox(e.grid,p);sr.objects.push({sourceElementId:e.id,sourceElementType:e.type,sourceGrid:e.grid,sourceBounds:b,targetBounds:sz(b),geometry:'exact grid formula',targetId:null});
   if(e.type==='text'){
    const r=textRole(e,family,String(e.text??''),p.editorial),pt=p.editorial&&e.grid.row===1&&e.role!=='label'?24:0,pb=p.editorial&&e.role==='title'?12+p.strongRule:0;
    txt(e.role||'body',e.text,{...b,y:b.y+pt,h:Math.max(0,b.h-pt-pb)},r.size,r.lh,r.weight,tone(p,e.tone),['kicker','label'].includes(e.role)?p.fontMono:p.fontDisplay,e.align||'left',r.letter,r.upper);
    if(p.editorial&&e.role==='title')rect('title-rule',{x:b.x,y:b.y+b.h-p.strongRule,w:b.w,h:p.strongRule},p.ink);
   } else if(e.type==='metric'){
    panel(e,b);const inverse=p.editorial&&e.tone==='inverse';let px=p.editorial?(inverse?38:0):31,pt=p.editorial?(inverse?34:18+p.strongRule):31,pbot=p.editorial?(inverse?34:0):31;
    if(inverse)rect('inverse-panel',b,p.dark);else if(p.editorial)rect('metric-rule',{x:b.x,y:b.y,w:b.w,h:p.strongRule},p.ink);
    const value=String(e.value??''),n=[...value].length,fs=p.editorial?(e.tone!=='inverse'?(n<=8?104:76):(n<=6?312:n<=10?220:154)):88,iw=b.w-2*px;
    const children=[{key:'label',text:e.label,size:19,lh:1.2,weight:700,color:inverse?p.onDark:p.muted,font:p.fontMono,letter:.12,upper:true},{key:'value',text:value,size:fs,lh:.9,weight:900,color:inverse?p.onDark:tone(p,e.tone||'accent'),font:p.fontDisplay,letter:-.045}];
    if(e.detail!=null)children.push({key:'detail',text:e.detail,size:p.editorial?19:22,lh:1.4,weight:400,color:inverse?p.onDark:p.muted,font:p.fontBody,letter:0});
    if(e.trend!=null)children.push({key:'trend',text:e.trend,size:18,lh:1.2,weight:750,color:tone(p,e.tone==='critical'?'critical':'positive'),font:p.fontMono,letter:0,boxPad:7});
    children.forEach(c=>c.h=wrapText(c.upper?String(c.text).toUpperCase():c.text,iw,c.size,c.letter).length*c.size*c.lh+2*(c.boxPad||0));
    const innerH=b.h-pt-pbot,total=children.reduce((s,c)=>s+c.h,0),gap=Math.max(0,(innerH-total)/(children.length-1));let y=b.y+pt;
    if(total>innerH)loss(`${sid}/${e.id}`,'source text overflow','unverified',`Estimated content height ${rnd(total)} exceeds source card inner height ${rnd(innerH)}; original CSS may shrink line boxes or clip. No semantic text removed.`);
    for(const c of children){txt(c.key,c.text,{x:b.x+px,y:y+(c.boxPad||0),w:iw,h:c.h-2*(c.boxPad||0)},c.size,c.lh,c.weight,c.color,c.font,'left',c.letter,c.upper);y+=c.h+gap;}
   } else if(e.type==='list'){
    panel(e,b);if(p.editorial)rect('list-rule',{x:b.x,y:b.y,w:b.w,h:p.strongRule},p.ink);
    const dense=p.editorial&&e.items.length>6,px=p.editorial?0:31,pt=p.editorial?12+p.strongRule:31,iw=b.w-2*px;let y=b.y+pt;
    (e.items||[]).forEach((item,i)=>{
     const it=typeof item==='object'?item:{title:String(item),body:''};
     if(i){y+=dense?6:12;rect(`list-separator-${i}`,{x:b.x+px,y,w:iw,h:1},p.line);y+=1+(dense?6:12);}
     const fs=dense?19:p.editorial?22:25,bs=dense?16:p.editorial?18:20,tw=iw-42,th=wrapText(it.title,tw,fs).length*fs*1.3,bh=it.body?wrapText(it.body,tw,bs).length*bs*1.42:0;
     txt(`list-${i+1}-number`,e.ordered?String(i+1).padStart(2,'0'):p.editorial?'—':'•',{x:b.x+px,y,w:30,h:18*1.45},18,1.45,800,tone(p,e.tone||'accent'),p.fontMono);
     txt(`list-${i+1}-title`,it.title,{x:b.x+px+42,y,w:tw,h:th},fs,1.3,p.editorial?760:720);
     if(it.body)txt(`list-${i+1}-body`,it.body,{x:b.x+px+42,y:y+th+(dense?2:5),w:tw,h:bh},bs,1.42,400,p.muted);
     y+=Math.max(18*1.45,th+(it.body?(dense?2:5)+bh:0));
    });
    if(y>b.y+b.h-(p.editorial?0:31))loss(`${sid}/${e.id}`,'source list overflow','unverified',`Estimated list bottom ${rnd(y)} exceeds card content bottom ${rnd(b.y+b.h-(p.editorial?0:31))}.`);
   } else if(e.type==='quote'){
    panel(e,b);if(p.editorial)rect('quote-rule',{x:b.x,y:b.y,w:b.w,h:p.strongRule},p.ink);
    const px=p.editorial?0:31,pt=p.editorial?20+p.strongRule:31,pbot=p.editorial?0:31,iw=b.w-2*px,q=String(e.quote??''),n=[...q].length,fs=p.editorial?(n<=18?132:n<=34?112:n<=60?92:72):42;
    const qh=wrapText(q,iw,fs,-.018).length*fs*1.24,ah=e.attribution!=null?wrapText(String(e.attribution),iw,20,.07).length*24:0,gap=p.editorial?18:26,total=(p.editorial?0:50+gap)+qh+(ah?gap+ah:0);let y=b.y+pt+Math.max(0,(b.h-pt-pbot-total)/2);
    if(!p.editorial){txt('quotation-mark','“',{x:b.x+px,y,w:iw,h:50},100,.5,900,tone(p,e.tone||'accent'),p.fontDisplay);y+=50+gap;}
    txt('quote',q,{x:b.x+px,y,w:iw,h:qh},fs,1.24,p.editorial?800:760,p.ink,p.fontDisplay,'left',-.018);y+=qh+gap;
    if(ah)txt('attribution',e.attribution,{x:b.x+px,y,w:iw,h:ah},20,1.2,400,p.muted,p.fontMono,'left',.07);
   } else if(e.type==='shape'){
    const shape=e.shape||'panel',fill=shape==='panel'&&(!e.tone||e.tone==='default')?p.surface:tone(p,e.tone||'accent');
    if(shape==='line'){const thick=p.editorial?p.strongRule:3;rect('line',e.grid.width>=e.grid.height?{x:b.x,y:b.y+(b.h-thick)/2,w:b.w,h:thick}:{x:b.x+(b.w-thick)/2,y:b.y,w:thick,h:b.h},fill);}
    else {const r=rect(shape,b,fill,shape==='circle'?0:shape==='panel'?p.radius:0,shape==='panel'?p.line:'transparent',shape==='panel'?1:0);if(shape==='circle')r.shape='ellipse';if(e.tone==='muted')r.opacity=.32;if(shape==='panel'&&p.shadow!=='none')loss(`${sid}/${e.id}`,'boxShadow','omitted',p.shadow);}
   } else if(e.type==='chart'){
    panel(e,b);if(p.editorial)rect('chart-rule',{x:b.x,y:b.y,w:b.w,h:p.strongRule},p.ink);
    const px=p.editorial?0:31,pt=p.editorial?18+p.strongRule:31,bb={x:b.x+px,y:b.y+pt,w:b.w-2*px,h:b.h-pt-(p.editorial?0:31)},data=e.data||[],kind=e.chartType||'bar';
    sr.chartSemantics??=[];sr.chartSemantics.push({sourceElementId:e.id,type:kind,data:clone(data),target:'editable graphic primitives, not native data-driven chart'});
    const color=i=>p.chartTreatment.series[i%p.chartTreatment.series.length]||p.accent;
    if(['bar','line'].includes(kind)){
     const sx=bb.w/1000,sy=bb.h/420,X=x=>bb.x+x*sx,Y=y=>bb.y+y*sy;let min=Math.min(0,...data.map(d=>d.value)),max=Math.max(0,...data.map(d=>d.value));if(min===max)[min,max]=[-1,1];const yy=v=>340-(v-min)/(max-min)*290,zero=yy(0);
     for(let i=0;i<4;i++)rect('chart-grid',{x:X(50),y:Y(66+i*91)-(p.editorial?p.hairline:2)*sy/2,w:900*sx,h:(p.editorial?p.hairline:2)*sy},p.chartTreatment.grid);
     rect('chart-baseline',{x:X(50),y:Y(zero)-(p.editorial?p.strongRule:2)*sy/2,w:900*sx,h:(p.editorial?p.strongRule:2)*sy},p.ink);
     const pts=[];data.forEach((d,i)=>{
      let cx=kind==='bar'?60+i*(900/data.length)+(900/data.length)/2:70+i/Math.max(1,data.length-1)*860,cy=yy(d.value);pts.push([X(cx),Y(cy)]);
      if(kind==='bar'){const bw=Math.min(96,(900/data.length)*.58),h=Math.max(2,Math.abs(cy-zero)),y=d.value>0?cy:d.value<0?zero:zero-1;rect(`bar-${i+1}`,{x:X(cx-bw/2),y:Y(y),w:bw*sx,h:h*sy},color(i),p.chartTreatment.barRadius*Math.min(sx,sy));}
      const label=String(d.label).length>10?String(d.label).slice(0,9)+'…':String(d.label);txt(`chart-label-${i+1}`,label,{x:X(cx-100),y:Y(362),w:200*sx,h:24*sy},20*Math.min(sx,sy),1.2,400,p.chartTreatment.label,p.fontBody,'center');
      if(e.showValues){const fy=kind==='bar'?(d.value<0?Math.min(368,zero+Math.abs(cy-zero)+24):Math.max(28,cy-12)):(d.value<0?Math.min(365,cy+28):Math.max(24,cy-18));txt(`chart-value-${i+1}`,formatDatum(d),{x:X(cx-100),y:Y(fy-19),w:200*sx,h:24*sy},(kind==='bar'?19:18)*Math.min(sx,sy),1.2,700,p.ink,p.fontBody,'center');}
     });
     if(kind==='line'){
      // Preserve segment endpoints using independently editable rotated rectangles; no accidental arrows.
      for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i];line(`chart-segment-${i}`,a[0],a[1],c[0],c[1],color(0),p.chartTreatment.strokeWidth*Math.min(sx,sy));}
      pts.forEach(([x,y],i)=>{const el=rect(`chart-point-${i+1}`,{x:x-9*sx,y:y-9*sy,w:18*sx,h:18*sy},color(i));el.shape='ellipse';});
     }
     loss(`${sid}/${e.id}`,'SVG preserveAspectRatio none text','uniform font approximation','Chart geometric coordinates are source-scaled. SVG nonuniformly stretched text is approximated by uniform font size; source chart data is retained verbatim.');
     if(kind==='line'&&Math.abs(sx-sy)>.001)loss(`${sid}/${e.id}`,'SVG nonuniform line stroke','uniform-width approximation','Source viewBox scaling stretches stroke differently by direction. Editable rotated target segments preserve centerline endpoints; uniform thickness uses the smaller scale.');
     if(kind==='bar'&&p.chartTreatment.barRadius&&Math.abs(sx-sy)>.001)loss(`${sid}/${e.id}`,'SVG nonuniform bar corner radius','uniform-radius approximation','Source SVG stretches rx/ry independently; SP roundRect uses a single cornerRadius. Smaller scaled radius is used and source data retained.');
    }else if(kind==='progress'){
     const rowH=28,max=Math.max(100,...data.map(d=>d.value)),gap=18,total=data.length*rowH+Math.max(0,data.length-1)*gap;let y=bb.y+(bb.h-total)/2;
     const valueW=e.showValues?70:0,gaps=e.showValues?32:16,free=bb.w-valueW-gaps,labelW=Math.max(120,free*.8/2.8),barW=free-labelW;
     data.forEach((d,i)=>{txt(`progress-label-${i+1}`,d.label,{x:bb.x,y,w:labelW,h:rowH},20,1.4,400,p.muted);rect('progress-track',{x:bb.x+labelW+16,y:y+7,w:barW,h:14},p.chartTreatment.grid,p.editorial?0:7);rect('progress-fill',{x:bb.x+labelW+16,y:y+7,w:barW*Math.min(1,d.value/max),h:14},color(i),p.editorial?0:7);if(e.showValues)txt('progress-value',formatDatum(d),{x:bb.x+bb.w-70,y,w:70,h:rowH},18,1.4,700,p.ink,p.fontMono,'right');y+=rowH+gap;});
    }else if(kind==='donut'){
     loss(`${sid}/${e.id}`,'donut arcs','editable polygon approximation','Native SP paths are vertex polylines rather than SVG circle arcs. Ring segments use ≤94 editable vertices; subtle curved edges are approximate. Generic renderer does not paint path objects.');
     const left=(bb.w-24)/1.72,right=bb.w-left-24,diam=Math.min(left,bb.h),cx=bb.x+left/2,cy=bb.y+bb.h/2,r=125*diam/420,sw=58*diam/420,total=Math.max(1,data.reduce((s,d)=>s+d.value,0));let angle=-Math.PI/2;
     data.forEach((d,i)=>{const delta=d.value/total*Math.PI*2,count=Math.max(2,Math.ceil(delta/(Math.PI*2)*44)),pts=[];for(let j=0;j<=count;j++){const a=angle+delta*j/count;pts.push([cx+(r+sw/2)*Math.cos(a),cy+(r+sw/2)*Math.sin(a)]);}for(let j=count;j>=0;j--){const a=angle+delta*j/count;pts.push([cx+(r-sw/2)*Math.cos(a),cy+(r-sw/2)*Math.sin(a)]);}const bounds={x:cx-(r+sw/2),y:cy-(r+sw/2),w:2*r+sw,h:2*r+sw};add('path',`donut-segment-${i+1}`,bounds,{points:pts.map(([x,y])=>[rnd((x-bounds.x)/bounds.w),rnd((y-bounds.y)/bounds.h)]),closed:true,fill:hex(color(i),bg),stroke:'transparent',strokeWidth:1});angle+=delta;const ly=bb.y+(bb.h-(data.length*25+(data.length-1)*12))/2+i*37;const dot=rect('legend-dot',{x:bb.x+left+24,y:ly+7,w:10,h:10},color(i));dot.shape='ellipse';txt('legend-label',d.label,{x:bb.x+left+46,y:ly,w:Math.max(1,right-90),h:25},18,1.4,400,p.muted);if(e.showValues)txt('legend-value',formatDatum(d),{x:bb.x+bb.w-65,y:ly,w:65,h:25},18,1.4,700,p.ink,p.fontMono,'right');});
    } else throw Error(`Unsupported actual chart kind ${kind}`);
   } else if(e.type==='media')throw Error(`Media conversion needs separately verified asset, stopped at ${sid}/${e.id}`);
   else throw Error(`Unsupported v4 element ${e.type}`);
  }
  current=null;
  if(measures){
   const measured=measures.find(m=>m.logicalId===logical.id&&m.variantId==='v4'&&m.theme===theme);
   if(!measured)throw Error(`Missing DOM measurements for ${sid}`);
   if(measured.components.length!==material.elements.length)throw Error(`Stale DOM component count for ${sid}`);
   sr.domGeometryCheck=[];sr.domTextMatches=[];
   measured.components.forEach(component=>{
    const sourceElement=material.elements[component.index];if(!sourceElement||sourceElement.type!==component.type)throw Error(`Stale DOM component ${sid}/${component.index}`);
    let expected=gridBox(sourceElement.grid,p);
    if(sourceElement.type==='shape'&&sourceElement.shape==='line'){const thick=p.editorial?p.strongRule:3;expected=sourceElement.grid.width>=sourceElement.grid.height?{x:expected.x,y:expected.y+(expected.h-thick)/2,w:expected.w,h:thick}:{x:expected.x+(expected.w-thick)/2,y:expected.y,w:thick,h:expected.h};}
    const delta=Math.max(...['x','y','w','h'].map(k=>Math.abs(component.bounds[k]-expected[k])));
    sr.domGeometryCheck.push({sourceElementId:sourceElement.id,maxDifferenceSourcePixels:rnd(delta),passed:delta<=.15});
    if(delta>.15)throw Error(`DOM grid mismatch ${sid}/${sourceElement.id}: ${delta}`);
    for(const [rowIndex,row]of (component.listRows||[]).entries()){
     if(!rowIndex||!row.borderTopWidth)continue;
     const info=sr.objects.find(o=>o.targetId&&o.sourceElementId===sourceElement.id&&slide.elements.find(e=>e.id===o.targetId)?.name===`list-separator-${rowIndex}`);
     if(info){const bounds={x:row.bounds.x,y:row.bounds.y,w:row.bounds.w,h:row.borderTopWidth};Object.assign(slide.elements.find(e=>e.id===info.targetId),sz(bounds));info.estimatedSourceBounds=info.sourceBounds;info.sourceBounds=bounds;info.targetBounds=sz(bounds);info.geometry='measured rendered source DOM border';}
    }
    const consumed=new Set();
    for(const info of sr.objects.filter(o=>o.targetId&&o.sourceElementId===sourceElement.id&&o.sourceText!==undefined)){
     const matchIndex=component.texts.findIndex((t,i)=>!consumed.has(i)&&t.text.trim()===info.sourceText.trim());
     if(matchIndex<0)throw Error(`DOM text missing or stale ${sid}/${sourceElement.id}/${info.sourceText}`);
     consumed.add(matchIndex);const measuredText=component.texts[matchIndex],target=slide.elements.find(e=>e.id===info.targetId);
     const mb=measuredText.bounds,cb=component.bounds;if(measuredText.clippedBy?.length||mb.x<cb.x-.15||mb.y<cb.y-.15||mb.x+mb.w>cb.x+cb.w+.15||mb.y+mb.h>cb.y+cb.h+.15)throw Error(`SOURCE_CLIPPING_REVIEW_REQUIRED ${sid}/${sourceElement.id}/${info.sourceText}: measured source text exceeds visible component; repair source or explicitly handle clipping before delivery`);
     const originalTargetBounds=Object.fromEntries(['x','y','w','h'].map(k=>[k,target[k]]));
     Object.assign(target,sz(measuredText.bounds));
     target.text=(measuredText.lines.length?measuredText.lines:[measuredText.text]).join('\n');
     if(measuredText.textTransform==='uppercase')target.text=target.text.toUpperCase();
     info.estimatedSourceBounds=info.sourceBounds;info.sourceBounds=measuredText.bounds;info.targetBounds=sz(measuredText.bounds);info.geometry='measured rendered source DOM';info.wrapMethod='source browser Range line measurement';info.sourceMeasuredStyle=measuredText;info.estimatedLines=measuredText.lines.length;
     sr.domTextMatches.push({targetId:target.id,sourceText:info.sourceText,originalTargetBounds,measuredTargetBounds:sz(measuredText.bounds)});
    }
   });
  }
  // On-slide disclosure uses otherwise empty bottom margin; it does not replace source copy.
  txt('conversion-disclosure','虚构演示 · Dashi v4 → SP 结构样例',{x:p.padX??p.pad,y:1038,w:1600,h:20},13,1.3,400,p.muted,p.fontBody);
  const visible=slide.elements.filter(e=>e.type==='text').map(e=>e.text.replace(/\n/g,'')).join('\n');
  sr.contentCheck={missingFacts:[...sr.sourceFacts,...sr.sourceChartFacts].filter(f=>!visible.includes(f)),unitsPreserved:true};if(sr.contentCheck.missingFacts.length)throw Error(`Missing facts ${sid} ${JSON.stringify(sr.contentCheck.missingFacts)}`);
  doc.slides.push(slide);report.slides.push(sr);
 }
 const thinObjects=doc.slides.flatMap(s=>s.elements).filter(e=>e.w<2||e.h<2);if(thinObjects.length)loss('all-slides','native minimum object extent','renderer limitation',`${thinObjects.length} canonical objects have width/height below 2 target pixels. Pinned native objectNode clamps rendered boxes to at least 2 px, so hairlines may become thicker. Canonical fractional geometry is retained; no product code is changed.`);
 // Full semantic equality for every source-defined property, allowing adapter-added defaults only.
 function compareSubset(expected,actual,where='document'){if(Array.isArray(expected)){if(!Array.isArray(actual)||expected.length!==actual.length)throw Error(`Roundtrip length ${where}`);expected.forEach((v,i)=>compareSubset(v,actual[i],`${where}[${i}]`));}else if(expected&&typeof expected==='object'){for(const [k,v]of Object.entries(expected))compareSubset(v,actual?.[k],`${where}.${k}`);}else if(expected!==actual)throw Error(`Roundtrip mismatch ${where}: ${expected} != ${actual}`);}
 const localIds=new Set();for(const slide of doc.slides){if(localIds.has(slide.id))throw Error('Duplicate ID');localIds.add(slide.id);for(const element of slide.elements){if(localIds.has(element.id))throw Error('Duplicate ID');localIds.add(element.id);if(!['x','y','w','h'].every(k=>Number.isFinite(element[k]))||element.w<0||element.h<0)throw Error('Invalid geometry');if(element.x<0||element.y<0||element.x+element.w>1280+.001||element.y+element.h>720+.001)throw Error('Outside canvas');}}
 report.localSanityCheck='passed finite geometry, canvas bounds, unique IDs and source fact coverage; this is not the official SP validator';
 for(const [branch,core,adapter]of [['main',mainCore,mainAdapter],['pr3',pr3Core,pr3Adapter]]){
  if(!core||!adapter){report.validation[branch]={commit:SOURCES[branch],schema:{valid:null,errors:[],warnings:[],notRun:true},status:'not_run: SP original code intentionally excluded from distributable conversion kit'};continue;}
  const valid=core.validateDocument(doc);if(!valid.valid||valid.warnings.length)throw Error(`${branch} validation ${JSON.stringify(valid)}`);
  const imported=core.importDocument(JSON.stringify(doc));compareSubset(doc,imported);
  const native=adapter.canonicalToEditor(imported),back=adapter.editorToCanonical(native,{baseDocument:imported});compareSubset(doc,back);
  const coreDoc=new core.DocumentCore(imported),slide=doc.slides[0],text=slide.elements.find(e=>e.type==='text');
  const changed=coreDoc.edit([{type:'updateElement',slideId:slide.id,elementId:text.id,properties:{text:text.text+' [EDIT TEST]',x:text.x+1}}],{expectedRevision:0});
  if(changed.slides[0].elements.find(e=>e.id===text.id).text!==text.text+' [EDIT TEST]')throw Error('Edit failed');
  const undone=coreDoc.undo({expectedRevision:1});compareSubset(doc.slides,undone.slides);
  const saved=core.importDocument(JSON.stringify(back));compareSubset(doc,saved);
  const shape=doc.slides.flatMap(s=>s.elements).find(e=>e.type==='shape');
  report.validation[branch]={commit:SOURCES[branch],schema:valid,coreImport:'passed',canonicalNativeCanonical:'passed; all source-defined fields equal, adapter-added defaults allowed',serializedSaveReopen:'passed in pure Core',editableTextMutation:'passed in Core',undo:'passed in Core',editableShapeCount:doc.slides.flatMap(s=>s.elements).filter(e=>e.type==='shape').length,nativeObjectCount:native.slides.reduce((s,v)=>s+v.objects.length,0),browserEditorInteraction:'not_run'};
 }
 if(measures){const l=report.lossManifest.find(x=>x.property==='textWrap / text metrics');l.handling='source DOM measured; SP typography unverified';l.detail='Source rendered text boxes and line breaks reconciled to actual browser DOM. SP native font availability, font weight quantization, baseline and clipping remain unverified.';report.geometryStatus='All v4 grids checked against actual rendered source DOM; text boxes and line breaks reconciled to browser measurements. SP native rendering still unverified.';report.sourceDomMeasurement={path:'bespoke-dom-measurements.json',sha256:sha(fs.readFileSync(measureFile,'utf8')),matchedTextObjects:report.slides.reduce((n,s)=>n+(s.domTextMatches?.length||0),0)};}
 const uiFile=path.join(ROOT,theme,'sp-native-ui-qa.json');if(fs.existsSync(uiFile)){const ui=JSON.parse(fs.readFileSync(uiFile,'utf8'));if(ui.sourceSampleSha256===sha(JSON.stringify(doc,null,2))){report.nativeEditorUIAttempt=ui;report.nativeEditorVisualQA=ui.status;}else report.priorNativeUIAttempt={status:'stale sample hash; no UI conclusion for current sample',sourceSampleSha256:ui.sourceSampleSha256};}
 report.statistics={slides:doc.slides.length,elements:doc.slides.reduce((s,v)=>s+v.elements.length,0),types:Object.fromEntries([...new Set(doc.slides.flatMap(s=>s.elements.map(e=>e.type)))].map(t=>[t,doc.slides.flatMap(s=>s.elements).filter(e=>e.type===t).length])),assets:doc.assets.length,rasterizedSlides:0,nativeDataDrivenCharts:doc.slides.flatMap(s=>s.elements).filter(e=>e.type==='chart').length,bytes:Buffer.byteLength(JSON.stringify(doc))};
 if(genericRenderer){const {exportHTML,importHTML,renderSlideSVG,inspectRenderCompatibility}=genericRenderer;const genericHTML=await exportHTML(doc);if(JSON.stringify(importHTML(genericHTML))!==JSON.stringify(doc))throw Error('Generic HTML full-document roundtrip mismatch');
 report.validation.main.genericHTMLExportImport='passed exact full document equality';report.validation.main.genericRenderCompatibility=inspectRenderCompatibility(doc);
 fs.writeFileSync(path.join(ROOT,theme,'sp-generic-preview.html'),genericHTML);
 for(const slide of doc.slides)fs.writeFileSync(path.join(ROOT,theme,`sp-generic-${slide.id}.svg`),renderSlideSVG(doc,slide.id));}else{report.validation.main.genericHTMLExportImport='not_run: standalone playback bundle intentionally omitted from source-only kit';}
 fs.writeFileSync(path.join(ROOT,theme,'sp-sample.json'),JSON.stringify(doc,null,2));
 fs.writeFileSync(path.join(ROOT,theme,'sp-mapping-report.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify({theme,...report.statistics,losses:report.lossManifest.length,main:report.validation.main.schema.valid===true?'pass':'not_run',pr3:report.validation.pr3.schema.valid===true?'pass':'not_run',sourceChartTypes:report.slides.flatMap(s=>(s.chartSemantics||[]).map(c=>c.type))}));
 return report;
}
const themes=process.argv.slice(2).filter(x=>x!=='--unmeasured');if(!themes.length)throw Error('Pass theme IDs explicitly after their canonical goal files are ready.');
for(const theme of themes){if(!/^theme\d{2}$/.test(theme))throw Error('Invalid theme');await build(theme);}
